
import { useState } from "react";
import "./App.css";
import { Doughnut } from "react-chartjs-2";
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend);

function App() {
    const [taches, setTaches] = useState([
        { nom: "Créer une page", duree: "2h", statut: "En cours" },
        { nom: "Ajouter CSS", duree: "1h", statut: "Traité" },
        { nom: "Tester le projet", duree: "3h", statut: "Non traité" }
    ]);

    const [nom, setNom] = useState("");
    const [duree, setDuree] = useState("");
    const [statut, setStatut] = useState("Non traité");

    function ajouterTache() {
        if (nom.trim() === "" || duree.trim() === "") {
            alert("Remplir tous les champs");
            return;
        }

        const nouvelleTache = {
            nom: nom.trim(),
            duree: duree.trim(),
            statut: statut
        };

        setTaches([...taches, nouvelleTache]);

        setNom("");
        setDuree("");
        setStatut("Non traité");
    }

    function supprimerTache(index) {
        setTaches(taches.filter((tache, i) => i !== index));
    }

    const traite = taches.filter((tache) => tache.statut === "Traité").length;
    const enCours = taches.filter((tache) => tache.statut === "En cours").length;
    const nonTraite = taches.filter((tache) => tache.statut === "Non traité").length;

    const data = {
        labels: ["Traité", "En cours", "Non traité"],
        datasets: [
            {
                data: [traite, enCours, nonTraite],
                backgroundColor: ["green", "orange", "red"]
            }
        ]
    };

    return (
        <div>
            <header>
                <h1>Task Manager</h1>
                <p>Gestion simple des tâches</p>
            </header>

            <main>
                <div className="formulaire">
                    <h2>Nouvelle tâche</h2>

                    <label>Nom de la tâche</label>
                    <input
                        type="text"
                        placeholder="Nom"
                        value={nom}
                        onChange={(e) => setNom(e.target.value)}
                    />

                    <label>Durée</label>
                    <input
                        type="text"
                        placeholder="Ex: 2h"
                        value={duree}
                        onChange={(e) => setDuree(e.target.value)}
                    />

                    <label>Statut</label>
                    <select
                        value={statut}
                        onChange={(e) => setStatut(e.target.value)}
                    >
                        <option>Non traité</option>
                        <option>En cours</option>
                        <option>Traité</option>
                    </select>

                    <button onClick={ajouterTache}>
                        Ajouter la tâche
                    </button>
                </div>

                <div className="liste">
                    <h2>Liste des tâches</h2>

                    <table>
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Nom</th>
                                <th>Durée</th>
                                <th>Statut</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            {taches.map((tache, index) => (
                                <tr key={index}>
                                    <td>{index + 1}</td>
                                    <td>{tache.nom}</td>
                                    <td>{tache.duree}</td>
                                    <td>{tache.statut}</td>
                                    <td>
                                        <button
                                            className="supprimer"
                                            onClick={() => supprimerTache(index)}
                                        >
                                            Supprimer
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>

                <div className="chart">
                    <h2>Statistiques des tâches</h2>
                    <Doughnut data={data} />
                </div>
            </main>
        </div>
    );
}

export default App;